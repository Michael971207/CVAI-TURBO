﻿CVAI Turbo – Project Spec
(… din tekst fra meldingen over – lim gjerne inn her …)
